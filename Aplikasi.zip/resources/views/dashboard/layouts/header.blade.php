<header class="navbar sticky-top flex-md-nowrap p-0 shadow">
    <a class="navbar-brand col-md-3 col-lg-2 me-0 px-3 fs-6 text-white text-center" href="#"><img src="{!! asset('img/logo-perumda.png') !!}" height="50" alt=""></a>
    <button class="navbar-toggler position-absolute d-md-none collapsed" type="button" data-bs-toggle="collapse"
        data-bs-target="#sidebarMenu" aria-controls="sidebarMenu" aria-expanded="false"
        aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <label for="" class="set text-dark">SIAKA <a style="font-size: 50%">(Sistem Informasi Inventarisasi Aset kantor)</a></label>
</header>