<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Cetak QR Code</title>
    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous" />
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }
        .container {
            max-width: 600px;
            margin: auto;
            text-align: center;
        }
        .asset-details {
            margin-top: 20px;
            border: 1px solid #ccc;
            padding: 10px;
        }
        .qr-code-img {
            max-width: 12.5%; /* 1/8 dari lebar kertas (100% / 8 = 12.5%) */
            height: auto;
        }
    </style>
</head>
<body>
    <div class="container">
        <?php if($asset->gambar_qr): ?>
        <h2>Detail Aset: <?php echo e($asset->nama); ?></h2>
        <div class="asset-details">
            <p><strong>Nama Aset:</strong> <?php echo e($asset->nama); ?></p>
            <p><strong>Kode:</strong> <?php echo e($asset->slug); ?></p>
            <p><strong>Ruangan:</strong> <?php echo e($asset->room->nama); ?></p>
        </div>
        <div class="qr-code-img">
            <img src="<?php echo e(asset('storage/' . $asset->gambar_qr)); ?>" alt="<?php echo e($asset->nama); ?>">
        </div>
        <?php endif; ?>
    </div>

    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>
</body>
</html>
<?php /**PATH C:\Pemrograman Web MI4A\sim-aset-kantor-laravel-main\resources\views/dashboard/report/print.blade.php ENDPATH**/ ?>