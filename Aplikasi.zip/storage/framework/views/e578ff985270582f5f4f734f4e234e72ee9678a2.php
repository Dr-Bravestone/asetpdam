

<?php $__env->startSection('container'); ?>
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">Tambah Aset Rusak</h1>
    </div>

    <div class="col-lg-8">
        <form method="post" action="/damagedassets" class="mb-5" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="mb-3">
                <label for="nama" class="form-label">Nama Aset</label>
                <select class="form-select" name="asset_id" id="nama" required autofocus>
                    <?php $__currentLoopData = $assets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $asset): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(old('asset_id') == $asset->id): ?>
                            <option value="<?php echo e($asset->id); ?>" selected><?php echo e($asset->nama); ?></option>
                        <?php else: ?>
                            <option value="<?php echo e($asset->id); ?>"><?php echo e($asset->nama); ?></option>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="mb-3">
                <label for="kondisi" class="form-label">Kondisi Aset</label>
                <textarea type="text" name="kondisi" class="form-control <?php $__errorArgs = ['kondisi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="kondisi"
                    rows="2" required><?php echo e(old('kondisi')); ?></textarea>
                <?php $__errorArgs = ['kondisi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback">
                        <?php echo e($message); ?>

                    </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="mb-3">
                <label for="solusi" class="form-label">Solusi</label>
                <select class="form-select" name="solusi" id="solusi" required autofocus>
                    <?php if(old('solusi')): ?>
                        <option value="<?php echo e(old('solusi')); ?>" hidden><?php echo e(old('solusi')); ?></option>
                        <option value="Perbaiki/Maintenance">Perbaiki/Maintenance</option>
                        <option value="Hibahkan">Hibahkan</option>
                        <option value="Hapus Dari Sistem">Hapus Dari Sistem</option>
                    <?php else: ?>
                        <option value="Perbaiki/Maintenance">Perbaiki/Maintenance</option>
                        <option value="Hibahkan">Hibahkan</option>
                        <option value="Hapus Dari Sistem">Hapus Dari Sistem</option>
                    <?php endif; ?>
                </select>
            </div>
            <div class="mb-3">
                <label for="jumlah" class="form-label">Jumlah Aset Rusak</label>
                <input type="text" name="jumlah" class="form-control <?php $__errorArgs = ['jumlah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                    id="jumlah" value="<?php echo e(old('jumlah')); ?>" required>
                <?php $__errorArgs = ['jumlah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback">
                        <?php echo e($message); ?>

                    </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <button type="submit" class="btn tombol">Tambah Aset Rusak</button>
            <a href="/damagedassets" class="btn tombol">Kembali</a>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Pemrograman Web MI4A\sim-aset-kantor-laravel-main\resources\views/dashboard/damaged-assets/create.blade.php ENDPATH**/ ?>