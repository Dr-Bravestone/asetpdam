<?php $__env->startSection('container'); ?>
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">Laporan Data Aset</h1>  
        <div class="mt-2"><h6>Login sebagai: <?php echo e(auth()->user()->email); ?></h6></div>

    </div>

    <div class="card-body">
        <div class="table-responsive col-lg-12 mb-3">
            <table id="myTable" class="table table-striped" style="width:100%">
                <thead>
                    <tr>
                        <th scope="col">No</th>
                        <th scope="col">Kode</th>
                        <th scope="col">Nama</th>
                        <th scope="col">Merek</th>
                        <th scope="col">Ruangan</th>
                        <th scope="col">Kategori</th>
                        <th scope="col">Jumlah</th>
                        <th scope="col">Tahun</th>
                        <th scope="col">Garansi</th>
                        <th scope="col">Harga</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $assets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $asset): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($asset->slug); ?></td>
                            <td><?php echo e($asset->nama); ?></td>
                            <td><?php echo e($asset->merek); ?></td>
                            <td><?php echo e($asset->room->nama); ?></td>
                            <td><?php echo e($asset->category->nama); ?></td>
                            <td><?php echo e($asset->jumlah); ?></td>
                            <td><?php echo e($asset->tahun); ?></td>
                            <td><?php echo e($asset->garansi); ?></td>
                            <td><?php echo e($asset->harga); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.report.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Pemrograman Web MI4A\sim-aset-kantor-laravel-main\resources\views/dashboard/report/aset.blade.php ENDPATH**/ ?>