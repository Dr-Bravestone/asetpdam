<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous" />
    <title>Print Label QR Code</title>
</head>
<body>
    <div class="container mt-5">
        <h4 class="text-center">Label QR Code Aset Meetup</h4><br>
        <div class="row">
            <?php $__currentLoopData = $assets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $asset): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($asset->gambar_qr): ?>
                    <div class="col-lg-2 col-md-4 col-sm-5 col-xs-2 mb-3">
                        <div class="card" style="width: 9rem;">
                            <div class="cut">
                                <img src="<?php echo e(asset('storage/' . $asset->gambar_qr)); ?>" alt="<?php echo e($asset->nama); ?>"
                                    class="img-fluid">
                            </div>
                            <small class="text-muted">
                                <b>Nama Aset : <?php echo e($asset->nama); ?></b><br>
                                Kode : <?php echo e($asset->slug); ?><br>
                                Ruangan : <?php echo e($asset->room->nama); ?><br>
                            </small>
                        </div>
                    </div>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>

</body>
</html><?php /**PATH C:\Pemrograman Web MI4A\sim-aset-kantor-laravel-main\resources\views/dashboard/report/printqr.blade.php ENDPATH**/ ?>