

<?php $__env->startSection('container'); ?>
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">Data Peminjaman Aset</h1>
        <div class="mt-2"><h6>Login sebagai: <?php echo e(auth()->user()->email); ?></h6></div>
        <a href="/borrowassets/create" class="btn tombol">Tambah Peminjaman Aset</a>
    </div>

    <?php if(session()->has('success')): ?>
        <div class="alert alert-success col-lg-12" role="alert">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <div class="card-body">
        <div class="table-responsive col-lg-12">
            <table id="myTable" class="table table-striped" style="width:100%">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">P. Jawab</th>
                        <th scope="col">Nama Aset</th>
                        
                        <th scope="col">Tanggal</th>
                        <th scope="col">Durasi</th>
                        <th scope="col">Status</th>
                        <th scope="col">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $pinjamaset; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pinjam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($pinjam->pj); ?></td>
                            <td><?php echo e($pinjam->asset->nama); ?></td>
                            
                            <td><?php echo e($pinjam->tgl_pinjam); ?></td>
                            <td><?php echo e($pinjam->durasi); ?> hari</td>
                            <td>
                                <?php if($pinjam->status == 'Dipinjam'): ?>
                                    <form action="/borrowassets/return/<?php echo e($pinjam->id); ?>" method="post" class="d-inline">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="status" value="Dikembalikan">
                                        <button class="badge bg-danger border-0"
                                            onclick="return confirm('Kembalikan aset ?')">
                                            Dipinjam
                                        </button>
                                    </form>
                                <?php else: ?>
                                    <div class="badge bg-primary"><?php echo e($pinjam->status); ?></div>
                                <?php endif; ?>
                            </td>
                            <td>
                                <a href="" class="badge bg-info" data-bs-toggle="modal"
                                    data-bs-target="#showModal<?php echo e($pinjam->id); ?>"><span data-feather="eye"></span>detail</a>
                                <!-- Start Modal -->
                                <div class="modal fade" id="showModal<?php echo e($pinjam->id); ?>" tabindex="-1">
                                    <div class="modal-dialog modal-dialog-centered">
                                        <div class="modal-content">
                                            <form>
                                                <div class="modal-header">
                                                    <h5 class="modal-title text-dark">Detail Peminjaman Aset</h5>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                        aria-label="Close"></button>
                                                </div>
                                                <div class="modal-body">
                                                    <div class="mb-2">
                                                        <label class="form-label">Penanggung Jawab</label>
                                                        <input type="text" class="form-control" readonly
                                                            value="<?php echo e($pinjam->pj); ?>">
                                                    </div>
                                                    <div class="mb-2">
                                                        <label class="form-label">Nama Aset</label>
                                                        <textarea type="text" class="form-control" readonly><?php echo e($pinjam->asset->nama); ?></textarea>
                                                    </div>
                                                    
                                                    <div class="mb-2">
                                                        <label class="form-label">Tanggal Pinjam</label>
                                                        <input type="text" class="form-control" readonly
                                                            value="<?php echo e($pinjam->tgl_pinjam); ?>">
                                                    </div>
                                                    <div class="mb-2">
                                                        <label class="form-label">Durasi Pinjam</label>
                                                        <input type="text" class="form-control" readonly
                                                            value="<?php echo e($pinjam->durasi); ?>">
                                                    </div>
                                                    <div class="mb-2">
                                                        <label class="form-label">Status</label>
                                                        <input type="text" class="form-control" readonly
                                                            value="<?php echo e($pinjam->status); ?>">
                                                    </div>
                                                    <div class="mb-2">
                                                        <label class="form-label">Created</label>
                                                        <input type="text" class="form-control" readonly
                                                            value="<?php echo e($pinjam->created_at); ?>">
                                                    </div>
                                                    <div>
                                                        <label class="form-label">Updated</label>
                                                        <input type="text" class="form-control" readonly
                                                            value="<?php echo e($pinjam->updated_at); ?>">
                                                    </div>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary"
                                                        data-bs-dismiss="modal">Close</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                                <!-- End Modal -->
                                <a href="/borrowassets/<?php echo e($pinjam->id); ?>/edit" class="badge bg-warning"><span
                                        data-feather="edit"></span>edit</a>
                                <form action="/borrowassets/<?php echo e($pinjam->id); ?>" method="post" class="d-inline">
                                    <?php echo method_field('delete'); ?>
                                    <?php echo csrf_field(); ?>
                                    <button class="badge bg-danger border-0" onclick="return confirm('Are you Sure?')">
                                        <span data-feather="x-circle"></span>hapus
                                    </button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>

        </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Pemrograman Web MI4A\sim-aset-kantor-laravel-main\resources\views/dashboard/borrowassets/index.blade.php ENDPATH**/ ?>