<?php $__env->startSection('container'); ?>
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 border-bottom">
        <h1 class="h2">Selamat datang kembali, <?php echo e(auth()->user()->email); ?></h1>
    </div>

    <div class="info-data col-lg-12 mt-3 mb-3">
        <div class="card asset">
            <div class="head">
                <div>
                    <h5><b>Total Aset</b></h5>
                    <h2 class="warna-meetup"><?php echo e($totalaset); ?></h2>
                </div>
                <i class='bx bxs-folder-open icon-data'></i>
            </div>
        </div>
        <div class="card rusak">
            <div class="head">
                <div>
                    <h5><b>Total Ruangan</b></h5>
                    <h2 class="warna-meetup"><?php echo e($totalruangan); ?></h2>
                </div>
                <i class='bx bxs-error-alt icon-data'></i>
            </div>
        </div>
        <div class="card maintenance">
            <div class="head">
                <div>
                    <h5><b>Total Kategori</b></h5>
                    <h2 class="warna-meetup"><?php echo e($totalkategori); ?></h2>
                </div>
                <i class='bx bxs-calendar-check icon-data'></i>
            </div>
        </div>
    </div>

    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Pemrograman Web MI4A\sim-aset-kantor-laravel-main\resources\views/dashboard/index.blade.php ENDPATH**/ ?>