<?php $__env->startSection('container'); ?>
<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">Data Aset</h1> 
    <div class="ml-auto d-flex">
        <div class="mt-2"><h6>Login sebagai: <?php echo e(auth()->user()->email); ?></h6></div>
        <a href="/reportqr" class="btn btn-dark mb-3 mx-1">Print QR Aset</a>   
        <a href="/assets/create" class="btn tombol mb-3 ml-2">Tambah Aset Baru</a>   
    </div>
</div>


    <?php if(session()->has('success')): ?>
        <div class="alert alert-success col-lg-12" role="alert">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
    <?php if($errors->count() > 0): ?>
        <div class="alert alert-danger col-lg-12" role="alert">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($error); ?>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>

    <div class="card-body">
        <div class="table-responsive col-lg-12 mb-3">
            <table id="myTable" class="table table-striped" style="width:100%">
                <thead>
                    <tr>
                        <th scope="col">No</th>
                        <th scope="col">Nama</th>
                        <th scope="col">Merek</th>
                        <th scope="col">Ruangan</th>
                        <th scope="col">Kategori</th>
                        <th scope="col">Tahun</th>
                        <th scope="col">Foto</th>
                        <th scope="col">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $assets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $asset): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($asset->nama); ?></td>
                            <td><?php echo e($asset->merek); ?></td>
                            <td><?php echo e($asset->room->nama); ?></td>
                            <td><?php echo e($asset->category->nama); ?></td>
                            <td><?php echo e($asset->tahun); ?></td>
                            <td><img src="<?php echo e(Storage::url($asset->foto)); ?>" alt="Asset Image" width="100"></td>

                            <td>
                                <a href="/assets/<?php echo e($asset->slug); ?>" class="badge bg-info"><span
                                        data-feather="eye"></span>detail</a>
                                
                                <a href="/assets/<?php echo e($asset->slug); ?>/edit" class="badge bg-warning"><span
                                        data-feather="edit"></span>edit</a>
                                <form action="/assets/<?php echo e($asset->slug); ?>" method="post" class="d-inline">
                                    
                                    <?php echo method_field('delete'); ?>
                                    <?php echo csrf_field(); ?>
                                    <button class="badge bg-danger border-0" onclick="return confirm('Are you Sure?')">
                                        <span data-feather="x-circle"></span>delete
                                    </button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>

            
            

        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Pemrograman Web MI4A\sim-aset-kantor-laravel-main\resources\views/dashboard/data-assets/index.blade.php ENDPATH**/ ?>