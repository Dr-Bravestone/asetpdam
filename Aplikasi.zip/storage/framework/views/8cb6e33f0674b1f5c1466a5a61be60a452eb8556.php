<nav id="sidebarMenu" class="col-md-3 col-lg-2 d-md-block sidebar collapse mt-3">
    <div class="position-sticky pt-3">
        <ul class="nav flex-column list-unstyled ps-0">
            <li class="nav-item">
                <a class="nav-link <?php echo e(Request::is('dashboard') ? 'active' : ''); ?>" href="/dashboard">
                    <span data-feather="home" class="align-text-bottom"></span>
                    Dashboard
                </a>
            </li>
            
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin')): ?>
            <h5 class="sidebar-heading d-flex justify-content-between align-items-center px-3 mt-3 mb-1 off">
                <span>Data Master</span>
            </h5>
                <li class="nav-item">
                    <a class="nav-link <?php echo e(Request::is('assets*') ? 'active' : ''); ?>" href="/assets">
                        <span data-feather="hard-drive" class="align-text-bottom"></span>
                        Data Aset
                    </a>
                </li>

                <li class="nav-item">
                    <a class="nav-link <?php echo e(Request::is('categories*') ? 'active' : ''); ?>" href="/categories">
                        <span data-feather="grid" class="align-text-bottom"></span>
                        Kategori Aset
                    </a>
                </li>

                <li class="nav-item">
                    <a class="nav-link <?php echo e(Request::is('rooms*') ? 'active' : ''); ?>" href="/rooms">
                        <span data-feather="layers" class="align-text-bottom"></span>
                        Ruangan Aset
                    </a>
                </li>
            <h5 class="sidebar-heading d-flex justify-content-between align-items-center px-3 mt-3 mb-1 off">
                <span>Monitoring Aset</span>
            </h5>
                <li class="nav-item">
                    <a class="nav-link <?php echo e(Request::is('maintenances*') ? 'active' : ''); ?>" href="/maintenances">
                        <span data-feather="sliders" class="align-text-bottom"></span>
                        Pemeliharaan
                    </a>
                </li>

                
                <li class="nav-item">
                    <a class="nav-link <?php echo e(Request::is('borrowassets*') ? 'active' : ''); ?>" href="/borrowassets">
                        <span data-feather="share-2" class="align-text-bottom"></span>
                        Peminjaman Aset
                    </a>
                </li>
                
            <?php endif; ?>
            <h5 class="sidebar-heading d-flex justify-content-between align-items-center px-3 mt-3 mb-1 off">
                <span>Laporan</span>
            </h5>
                <li class="nav-item">
                    <a class="nav-link <?php echo e(Request::is('reportaset*') ? 'active' : ''); ?>" href="/reportaset">
                        <span data-feather="hard-drive" class="align-text-bottom"></span>
                        Data Aset
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo e(Request::is('reportmaintenance*') ? 'active' : ''); ?>" href="/reportmaintenance">
                        <span data-feather="sliders" class="align-text-bottom"></span>
                        Data Pemeliharaan
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo e(Request::is('reportborrow*') ? 'active' : ''); ?>" href="/reportborrow">
                        <span data-feather="share-2" class="align-text-bottom"></span>
                        Data Peminjaman
                    </a>
                </li>
                
        </ul>
    </div>
    <div class="d-flex flex-column flex-shrink-0 p-3">
        <div class="dropdown">
            <a href="#" class="d-flex align-items-center link-dark text-decoration-none dropdown-toggle"
                id="dropdownUser2" data-bs-toggle="dropdown" aria-expanded="false">
                <img src=`<?php echo e(auth()->user()->foto); ?>` alt="" width="32" height="32"
                    class="rounded-circle me-2">
                <strong><?php echo e(auth()->user()->email); ?></strong>
            </a>
            <ul class="dropdown-menu text-small shadow" aria-labelledby="dropdownUser2">
                
                <li>
                    <hr class="dropdown-divider">
                </li>
                <li>
                    <form action="/logout" method="post">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="dropdown-item">Logout <span data-feather="log-out" class="align-text-bottom"></span></button>
                    </form>
                </li>
            </ul>
        </div>
    </div>
</nav>
<?php /**PATH C:\Pemrograman Web MI4A\sim-aset-kantor-laravel-main\resources\views/dashboard/layouts/sidebar.blade.php ENDPATH**/ ?>