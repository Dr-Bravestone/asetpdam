<?php $__env->startSection('container'); ?>
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">Data Pemeliharaan</h1>
        <div class="mt-2"><h6>Login sebagai: <?php echo e(auth()->user()->email); ?></h6></div>
        <a href="/maintenances/create" class="btn tombol">Tambah Pemeliharaan Baru</a>
    </div>

    <?php if(session()->has('success')): ?>
        <div class="alert alert-success col-lg-12" role="alert">
            <?php echo e(session('success')); ?>

        </div>
        <?php endif; ?>
        
        <div class="card-body">
            <div class="table-responsive col-lg-12">
                <table id="myTable" class="table table-striped" style="width:100%">
                    <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Nama Aset</th>
                            <th scope="col">Ruangan</th>
                            <th scope="col">Deskripsi</th>
                            <th scope="col">Tgl Maintenance</th>
                            <th scope="col">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $maintenances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $maintenance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($maintenance->asset->nama); ?></td>
                                <td><?php echo e($maintenance->asset->room->nama); ?></td>
                                <td><?php echo e($maintenance->deskripsi); ?></td>
                                <td><?php echo e($maintenance->tgl); ?></td>
                                <td>
                                    <a href="" class="badge bg-info" data-bs-toggle="modal"
                                        data-bs-target="#showModal<?php echo e($maintenance->id); ?>"><span data-feather="eye"></span>detail</a>
                                    <!-- Start Modal -->
                                    <div class="modal fade" id="showModal<?php echo e($maintenance->id); ?>" tabindex="-1"
                                        aria-labelledby="exampleModalLabel" aria-hidden="true">
                                        <div class="modal-dialog modal-dialog-centered">
                                            <div class="modal-content">
                                                <form>
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="exampleModalLabel">Detail Pemeliharaan</h5>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                        aria-label="Close"></button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <div class="mb-1">
                                                            <label class="form-label">Nama Aset</label>
                                                            <input type="text" class="form-control" readonly
                                                                value="<?php echo e($maintenance->asset->nama); ?>">
                                                        </div>
                                                        <div class="mb-1">
                                                            <label class="form-label">Deskripsi</label>
                                                            <textarea type="text" class="form-control" rows="2" readonly><?php echo e($maintenance->deskripsi); ?></textarea>
                                                        </div>
                                                        <div class="mb-1">
                                                            <label class="form-label">Jumlah</label>
                                                            <input type="text" class="form-control" readonly
                                                                value="<?php echo e($maintenance->jumlah); ?>">
                                                        </div>
                                                        <div class="mb-1">
                                                            <label class="form-label">Tanggal Maintenance</label>
                                                            <input type="text" class="form-control" readonly
                                                                value="<?php echo e($maintenance->tgl); ?>">
                                                        </div>
                                                        
                                                        <div class="mb-1">
                                                            <label class="form-label">Biaya</label>
                                                            <input type="text" class="form-control" readonly
                                                                value="<?php echo e($maintenance->biaya); ?>">
                                                        </div>
                                                        <div class="mb-1">
                                                            <label class="form-label">Created</label>
                                                            <input type="text" class="form-control" readonly
                                                                value="<?php echo e($maintenance->created_at); ?>">
                                                        </div>
                                                        <div class="mb-1">
                                                            <label class="form-label">Updated</label>
                                                            <input type="text" class="form-control" readonly
                                                                value="<?php echo e($maintenance->updated_at); ?>">
                                                        </div>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- End Modal -->
                                    <a href="/maintenances/<?php echo e($maintenance->id); ?>/edit" class="badge bg-warning"><span
                                            data-feather="edit"></span>edit</a>
                                    <form action="/maintenances/<?php echo e($maintenance->id); ?>" method="post" class="d-inline">
                                        
                                        <?php echo method_field('delete'); ?>
                                        <?php echo csrf_field(); ?>
                                        <button class="badge bg-danger border-0" onclick="return confirm('Are you Sure?')">
                                            <span data-feather="x-circle"></span>hapus
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>

                
                

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Pemrograman Web MI4A\sim-aset-kantor-laravel-main\resources\views/dashboard/maintenance/index.blade.php ENDPATH**/ ?>