

<?php $__env->startSection('container'); ?>
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">Edit Peminjaman Aset</h1>
    </div>

    <div class="col-lg-8">
        <form method="post" action="/borrowassets/<?php echo e($pinjamaset->id); ?>" class="mb-5" enctype="multipart/form-data">
            <?php echo method_field('put'); ?>
            <?php echo csrf_field(); ?>
            <div class="mb-3">
                <label for="nama" class="form-label">Pilih Aset</label>
                <select class="form-select" name="asset_id" id="nama" required autofocus>
                    <?php $__currentLoopData = $assets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $asset): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(old('asset_id', $pinjamaset->asset_id) == $asset->id): ?>
                            <option value="<?php echo e($asset->id); ?>" selected><?php echo e($asset->nama); ?></option>
                        <?php else: ?>
                            <option value="<?php echo e($asset->id); ?>"><?php echo e($asset->nama); ?></option>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            
            <div class="mb-3">
                <label for="pj" class="form-label">Penanggung Jawab</label>
                <input type="text" name="pj" class="form-control <?php $__errorArgs = ['pj'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                    id="pj" value="<?php echo e(old('pj', $pinjamaset->pj)); ?>" required>
                <?php $__errorArgs = ['pj'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback">
                        <?php echo e($message); ?>

                    </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="mb-3">
                <label for="tgl_pinjam" class="form-label">Tanggal Pinjam</label>
                <input type="date" name="tgl_pinjam" class="form-control <?php $__errorArgs = ['tgl_pinjam'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                    id="tgl_pinjam" value="<?php echo e(old('tgl_pinjam', $pinjamaset->tgl_pinjam)); ?>" required>
                <?php $__errorArgs = ['tgl_pinjam'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback">
                        <?php echo e($message); ?>

                    </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="mb-3">
                <label for="durasi" class="form-label">Durasi Pinjam(/hari)</label>
                <input type="number" name="durasi" class="form-control <?php $__errorArgs = ['durasi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                    id="durasi" value="<?php echo e(old('durasi', $pinjamaset->durasi)); ?>" required>
                <?php $__errorArgs = ['durasi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback">
                        <?php echo e($message); ?>

                    </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="mb-3">
                <label for="status" class="form-label">Status</label>
                <select class="form-select" name="status" id="status" required autofocus>
                    <?php if(old('status')): ?>
                        <option value="<?php echo e(old('status')); ?>" hidden><?php echo e(old('status')); ?></option>
                        <option value="Dikembalikan">Dikembalikan</option>
                        <option value="Dipinjam">Dipinjam</option>
                    <?php else: ?>
                        <option value="<?php echo e($pinjamaset->status); ?>" hidden><?php echo e($pinjamaset->status); ?></option>
                        <option value="Dikembalikan">Dikembalikan</option>
                        <option value="Dipinjam">Dipinjam</option>
                        <option value="Tidak Dikembalikan">Tidak Dikembalikan</option>
                    <?php endif; ?>
                </select>
            </div>
            <button type="submit" class="btn tombol">Edit Peminjaman Aset</button>
            <a href="/borrowassets" class="btn tombol">Kembali</a>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Pemrograman Web MI4A\sim-aset-kantor-laravel-main\resources\views/dashboard/borrowassets/edit.blade.php ENDPATH**/ ?>