<?php $__env->startSection('container'); ?>

    <div class="container">
    
    <div class="row my-3">
        <div class="col-lg-8">
            <h1 class="mb-3">Aset : <?php echo e($asset->nama); ?></h1>

            <a href="/assets" class="btn btn-success">
                <span data-feather="arrow-left"></span> Kembali</a>
            <a href="/assets/<?php echo e($asset->slug); ?>/edit" class="btn btn-warning"><span data-feather="edit"></span> Edit</a>
            <form action="/assets/<?php echo e($asset->slug); ?>" method="post" class="d-inline">
                <?php echo method_field('delete'); ?>
                <?php echo csrf_field(); ?>
                <button class="btn btn-danger" onclick="return confirm('Are you Sure?')">
                    <span data-feather="x-circle"></span> Delete</button>
            </form>

            <div class="row gx-2">
                <div class="col-md-4">
                    <?php if($asset->foto): ?>
                        <div style="max-height: 350px; overflow:hidden;">
                            <img width="250" src="<?php echo asset('storage/'.$asset->foto); ?>"
                            alt="<?php echo e($asset->nama); ?>" class="img-fluid mt-3 img-thumbnail">
                        </div>
                    <?php endif; ?>
                </div>
                <div class="col-md-4">
                    <?php if($asset->gambar_qr): ?>
                        <div style="max-height: 350px; overflow:hidden;">
                            <img width="150" src="<?php echo e(asset('storage/' . $asset->gambar_qr)); ?>" class="img-fluid mt-3 img-thumbnail">
                        </div>
                    <?php endif; ?>
                </div>
            </div>
            
            <table class="table table-striped mt-3">
            <tbody>
                <tr>
                    <td>Kode Aset</td>
                    <td><?php echo e($asset->slug); ?></td>
                </tr>
                <tr>
                    <td>Nama</td>
                    <td><?php echo e($asset->nama); ?></td>
                </tr>
                <tr>
                    <td>Merek</td>
                    <td><?php echo e($asset->merek); ?></td>
                </tr>
                <tr>
                    <td>Kategori</td>
                    <td><?php echo e($asset->category->nama); ?></td>
                </tr>
                <tr>
                    <td>Ruangan</td>
                    <td><?php echo e($asset->room->nama); ?></td>
                </tr>
                <tr>
                    <td>Jumlah</td>
                    <td><?php echo e($asset->jumlah); ?></td>
                </tr>
                <tr>
                    <td>Tahun</td>
                    <td><?php echo e($asset->tahun); ?></td>
                </tr>
                <tr>
                    <td>Garansi</td>
                    <td><?php echo e($asset->garansi); ?></td>
                </tr>
                <tr>
                    <td>Harga</td>
                    <td>Rp <?php echo e($asset->harga); ?></td>
                </tr>
            </tbody>
            </table>

        </div>
    </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Pemrograman Web MI4A\sim-aset-kantor-laravel-main\resources\views/dashboard/data-assets/show.blade.php ENDPATH**/ ?>