<?php $__env->startSection('container'); ?>
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">Laporan Data Pemeliharaan</h1>  
        <div class="mt-2"><h6>Login sebagai: <?php echo e(auth()->user()->email); ?></h6></div>

    </div>

    <div class="card-body">
        <div class="table-responsive col-lg-12 mb-3">
            <table id="myTable" class="table table-striped" style="width:100%">
                <thead>
                    <tr>
                        <th scope="col">No</th>
                        <th scope="col">Nama</th>
                        <th scope="col">Deskripsi</th>
                        <th scope="col">Jumlah</th>
                        <th scope="col">Tanggal</th>
                        <th scope="col">Biaya</th>
                        
                        
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $maintenances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $maintenance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($maintenance->asset->nama); ?></td>
                            <td><?php echo e($maintenance->deskripsi); ?></td>
                            <td><?php echo e($maintenance->jumlah); ?></td>
                            <td><?php echo e($maintenance->tgl); ?></td>
                            <td><?php echo e($maintenance->biaya); ?></td>
                            
                            
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.report.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Pemrograman Web MI4A\sim-aset-kantor-laravel-main\resources\views/dashboard/report/maintenance.blade.php ENDPATH**/ ?>